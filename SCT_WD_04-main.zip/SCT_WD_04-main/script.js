const taskInput = document.getElementById("task-input");
const datetimeInput = document.getElementById("datetime-input");
const addBtn = document.getElementById("add-btn");
const taskList = document.getElementById("task-list");

addBtn.addEventListener("click", addTask);

function addTask() {
    const taskText = taskInput.value.trim();
    const taskTime = datetimeInput.value;

    if (taskText === "") {
        alert("Please enter a task.");
        return;
    }

    const li = document.createElement("li");
    li.className = "task-item";

    li.innerHTML = `
        <div class="task-info">
            <strong>${taskText}</strong><br>
            <small>${taskTime ? "⏰ " + taskTime.replace('T', ' ') : ""}</small>
        </div>
        <div class="task-actions">
            <button class="complete-btn">✔</button>
            <button class="edit-btn">✏️</button>
            <button class="delete-btn">🗑️</button>
        </div>
    `;

    taskList.appendChild(li);
    taskInput.value = "";
    datetimeInput.value = "";

    li.querySelector(".complete-btn").addEventListener("click", () => {
        li.classList.toggle("completed");
    });

    li.querySelector(".delete-btn").addEventListener("click", () => {
        li.remove();
    });

    li.querySelector(".edit-btn").addEventListener("click", () => {
        const newTask = prompt("Edit your task:", taskText);
        if (newTask !== null && newTask.trim() !== "") {
            li.querySelector("strong").textContent = newTask.trim();
        }
    });
}
